# Apex HRM — Vercel Deployment Guide

## What's in This Package

```
apex-hrm-vercel.zip (extract this first)
├── vercel.json        ← Vercel routing config
├── package.json       ← Runtime dependencies
├── api/
│   └── index.js       ← Express API (serverless function)
├── index.html         ← React app entry point
├── assets/            ← JS / CSS bundles
├── schema.sql         ← Database schema (run once in Neon SQL Editor)
├── .env.example       ← Environment variables reference
└── DEPLOY_GUIDE.md    ← This file
```

---

## Step 1 — Create a Free PostgreSQL Database (Neon)

1. Go to **https://neon.tech** → Sign up free
2. Create a new **Project** → name it anything (e.g. "apex-hrm")
3. Copy the **Connection String** — looks like:
   ```
   postgresql://user:pass@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require
   ```
4. In Neon dashboard → **SQL Editor** → paste the full contents of `schema.sql` → click **Run**
   - This creates all tables (employees, payroll, attendance, leaves, etc.)

---

## Step 2 — Deploy via Vercel CLI (recommended — takes 2 minutes)

### Install Vercel CLI once:
```
npm install -g vercel
```

### Deploy:
1. **Extract** this zip to a folder on your computer
2. Open a terminal / command prompt in that extracted folder
3. Run:
   ```
   vercel
   ```
4. Answer the prompts:
   - **Set up and deploy?** → Yes
   - **Which scope?** → your account
   - **Link to existing project?** → No
   - **Project name?** → apex-hrm (or anything)
   - **In which directory is your code located?** → `.` (just press Enter)
5. After it deploys, run this to add environment variables:
   ```
   vercel env add DATABASE_URL
   ```
   Paste your Neon connection string when asked. Then repeat for:
   ```
   vercel env add SESSION_SECRET
   vercel env add ADMIN_PASSWORD
   vercel env add NODE_ENV
   ```
   Set values: `SESSION_SECRET` = any random text, `ADMIN_PASSWORD` = your password, `NODE_ENV` = `production`

6. **Redeploy** to apply the env vars:
   ```
   vercel --prod
   ```

**Your app is now live!** The URL is shown after deploy (e.g. `https://apex-hrm.vercel.app`)

---

## Step 2 (Alternative) — Deploy via GitHub

If you prefer no terminal:

1. Create a **free GitHub account** at https://github.com
2. Create a new **repository** (public or private)
3. Upload all the extracted files to the repo (drag-and-drop in GitHub's web UI)
4. Go to **https://vercel.com** → "Add New Project" → "Import Git Repository"
5. Select your GitHub repo → click **Deploy**
6. Add environment variables in Vercel: Project → **Settings** → **Environment Variables**

   | Name | Value |
   |------|-------|
   | `DATABASE_URL` | your Neon connection string |
   | `SESSION_SECRET` | any random string |
   | `ADMIN_PASSWORD` | your chosen password |
   | `NODE_ENV` | `production` |

7. Go to **Deployments** → click the latest → **Redeploy**

---

## Default Login

| Field | Value |
|-------|-------|
| **URL** | `https://your-app.vercel.app/login` |
| **Username** | `admin` |
| **Password** | `admin123` (or whatever you set for ADMIN_PASSWORD) |

> Change your password in Settings → Security after first login.

---

## Troubleshooting

**"404: NOT_FOUND" on first open**
→ Make sure you extracted the zip and deployed the **contents** of the folder (not the folder itself)
→ The `vercel.json` must be at the **root** of what you deploy, not inside a subfolder

**App loads but login fails / data doesn't save**
→ Check that `DATABASE_URL` is set correctly in Vercel → Project → Settings → Environment Variables
→ Make sure you ran `schema.sql` in the Neon SQL Editor

**Vercel Functions error in logs**
→ Vercel dashboard → your project → "Functions" tab → click the `/api` function → view logs

---

## Environment Variables Reference

| Variable | Required | Default | Description |
|----------|:--------:|---------|-------------|
| `DATABASE_URL` | ✅ | — | PostgreSQL connection string (Neon/Supabase) |
| `SESSION_SECRET` | ✅ | (insecure default) | Random string for session signing |
| `ADMIN_USERNAME` | — | `admin` | Master admin username |
| `ADMIN_PASSWORD` | — | `admin123` | Master admin password |
| `NODE_ENV` | — | `development` | Set to `production` on Vercel |

---

## Support

Email: info@apexhr.cloud
